/*18番 小原 櫂
 * 「第6回レポート プログラム3」*/

#include <stdio.h>


int main(void)
 
{

    int a[10],i,j,x;
    for(i=0;i<10;i++)
    {
        printf("a[%d] = ",i); scanf("%d",&a[i]);
    }

    for(i=1; i<10; i++)
    {
        x = a[i]; j = i;
        while((j>0)&&(x > a[j-1]))
        {
            a[j] = a[j-1];
            j--;
        }
        a[j] = x;
    }

    for(i = 0; i<10; i++)
    {
        printf("%d : %d\n",i,a[i]);
    }
    return 0;
}

/*実行結果
a[0] = 7
a[1] = 5
a[2] = 6
a[3] = 8
a[4] = 8
a[5] = 2
a[6] = 2
a[7] = 5
a[8] = 8
a[9] = 4
0 : 8
1 : 8
2 : 8
3 : 7
4 : 6
5 : 5
6 : 5
7 : 4
8 : 2
9 : 2
*/