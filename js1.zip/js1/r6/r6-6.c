/*18番 小原 櫂
 * 「第6回レポート プログラム6」*/

#include <stdio.h>


int main(void)
 
{

    int a[10],i,j,tmp;
    for(i=0;i<10;i++)
    {
        printf("a[%d] = ",i); scanf("%d",&a[i]);
    }

    for(i=1; i<10; i++)
    {
        for(j=9; j>=1; j--)
        {
            if(a[j] > a[j-1])
            {
                tmp = a[j];
                a[j] = a[j-1];
                a[j-1] = tmp;
            }
        }
    }

    for(i = 0; i<10; i++)
    {
        printf("%d : %d\n",i,a[i]);
    }
    return 0;
}

/*実行結果
a[0] = 1
a[1] = 5
a[2] = 4
a[3] = 8
a[4] = 9
a[5] = 63
a[6] = 5
a[7] = 7
a[8] = 8
a[9] = 5
0 : 63
1 : 9
2 : 8
3 : 8
4 : 7
5 : 5
6 : 5
7 : 5
8 : 4
9 : 1
*/