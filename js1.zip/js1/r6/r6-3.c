/*18番 小原 櫂
 * 「第6回レポート プログラム3」*/

#include <stdio.h>


void change(int *x,int *y)
{
    int temp;

    temp = *x;
    *x = *y;
    *y = temp;
}

int main(void)
 
{

    int a[10],i,j,tmp;
    for(i=0;i<10;i++)
    {
        printf("a[%d] = ",i); scanf("%d",&a[i]);
    }

    for(i=1; i<10; i++)
    {
        j = i;
        while((j>0)&&(a[j] > a[j-1]))
        {
            tmp  = a[j]; a[j] = a[j-1]; a[j-1] = tmp;
            j--;
        }
        /*while文はプログラムが一通り終わって、条件にあっているのか確認するのであーる。*/
    }

    for(i = 0; i<10; i++)
    {
        printf("%d : %d\n",i,a[i]);
    }
    return 0;
}

/*実行結果
a[0] = 7
a[1] = 5
a[2] = 6
a[3] = 8
a[4] = 8
a[5] = 2
a[6] = 2
a[7] = 5
a[8] = 8
a[9] = 4
0 : 8
1 : 8
2 : 8
3 : 7
4 : 6
5 : 5
6 : 5
7 : 4
8 : 2
9 : 2
*/