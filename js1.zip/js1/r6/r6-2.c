/*18番 小原 櫂
 * 「第6回レポート プログラム2」*/

#include <stdio.h>
int main(void)
 
{
    int a[10],index,i,j,max;

    for(i=0; i<10; i++)
    {
        printf("a[%d] = ",i); scanf("%d",&a[i]);
    }

    for(i=0; i<9; i++)
    {
        max = a[i]; index = i;
        for(j = i + 1; j<10; j++)
        {
            if(a[j]>max)
            {
                max = a[j]; index = j;
            }
        }
        a[index] = a[i]; a[i] = max;

    }

    for(i=0; i<10; i++)
    {
        printf("%d : %d\n",i,a[i]);
    }
    return 0;
}

/*実行結果
a[0] = 6
a[1] = 5
a[2] = 7
a[3] = 8
a[4] = 41
a[5] = 56
a[6] = 85
a[7] = 2
a[8] = 58
a[9] = 52
0 : 85
1 : 58
2 : 56
3 : 52
4 : 41
5 : 8
6 : 7
7 : 6
8 : 5
9 : 2
*/