/*18番 小原 櫂
 * 「第6回レポート プログラム1」*/

#include <stdio.h>
int main(void)
 
{
    int a[10],index,i,j,temp;

    for(i=0; i<10; i++)
    {
        printf("a[%d] = ",i); scanf("%d",&a[i]);
    }

    for(i=0; i<9; i++)
    {
        index = i;
        for(j = i + 1; j<10; j++)
        {
            if(a[j] > a[index])
            {
                index = j;
            }
        
        }
        temp = a[i];
        a[i] = a[index];
        a[index] = temp;

    }

    for(i=0; i<10; i++)
    {
        printf("%d : %d\n",i,a[i]);
    }
    return 0;
}

/*実行結果
a[0] = 1
a[1] = 5
a[2] = 8
a[3] = 7
a[4] = 4
a[5] = 5
a[6] = 6
a[7] = 9
a[8] = 8
a[9] = 42
0 : 42
1 : 9
2 : 8
3 : 8
4 : 7
5 : 6
6 : 5
7 : 5
8 : 4
9 : 1
*/