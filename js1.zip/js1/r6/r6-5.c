/*18番 小原 櫂
 * 「第6回レポート プログラム5」*/

#include <stdio.h>


int main(void)
 
{

    int a[11],i,j,x;
    for(i=1;i<=10;i++)
    {
        printf("a[%d] = ",i); scanf("%d",&a[i]);
    }

    for(i=2; i<=10; i++)
    {
        x = a[i]; j = i;
        a[0] = a[i] + 1;
        while(x > a[j-1])
        {
            a[j] = a[j-1];
            j--;
        }
        a[j] = x;
    }

    for(i = 1; i<=10; i++)
    {
        printf("%d : %d\n",i,a[i]);
    }
    return 0;
}

/*実行結果
a[1] = 1
a[2] = 2
a[3] = 3
a[4] = 4
a[5] = 5
a[6] = 6
a[7] = 7
a[8] = 8
a[9] = 9
a[10] = 10
1 : 10
2 : 9
3 : 8
4 : 7
5 : 6
6 : 5
7 : 4
8 : 3
9 : 2
10 : 1
*/