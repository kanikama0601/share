/*18番 小原 櫂
 * 「第三回レポート プログラム1」*/

#include <stdio.h>


void change(int *x,int *y)
{
    int temp;

    temp = *x;
    *x = *y;
    *y = temp;
}

int main(void)
 
{

    int a[10],i,j;
    for(i=0;i<10;i++)
    {
        printf("a[%d] = ",i); scanf("%d",&a[i]);
    }

    for(i=1; i<10; i++)
    {
        j = i;
        while((j>0)&&(a[j] > a[j-1]))
        {
            change(&a[j],&a[j-1]);
            j = j - 1;
        } 
    }

    for(i = 0; i<10; i++)
    {
        printf("%d : %d\n",i,a[i]);
    }
    return 0;
}

/*実行結果

*/