/*18番 小原 櫂
 * 「第8回レポート プログラム3」*/

#include <stdio.h>
int gcm(int x, int y,int z)
{
    int c;

    if(x < y)
    {
        int temp = x;
        x = y;
        y = temp;
    }

    c = x % y;
    while(c != 0)
    {
        x = y;
        y = c;
        c = x % y;
    }

    c = z % y;
    while(c != 0)
    {
        z = y;
        y = c;
        c = z % y;
    }

    printf("%d\n",y);
}

int main(void)
 
{
    int x,y,z;
    printf("x = "); scanf("%d",&x);
    printf("y = "); scanf("%d",&y);
    printf("z = "); scanf("%d",&z);

    gcm(x,y,z);
    return 0;
}

/*実行結果
a = 12
b = 18
c = 30
6
*/