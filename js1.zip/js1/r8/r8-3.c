/*18番 小原 櫂
 * 「第8回レポート プログラム3」*/

#include <stdio.h>
int gcm(int x, int y)
{
    int c;

    if(x < y)
    {
        int temp = x;
        x = y;
        y = temp;
    }

    c = x % y;
    while(c != 0)
    {
        x = y;
        y = c;
        c = x % y;
    }

    printf("gcm = %d\n",y);
}

int main(void)
 
{
    int x,y;
    printf("a = "); scanf("%d",&x);
    printf("b = "); scanf("%d",&y);

    gcm(x,y);
    return 0;
}

/*実行結果
a = 60
b = 45
gcm = 15
*/