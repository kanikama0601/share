/*18番 小原 櫂
 * 「第8回レポート プログラム4」*/

#include <stdio.h>
int lcm(int x, int y)
{
    int c,d,tmp;

    if(y>x)
    {
        tmp = y;
        y = x;
        x = tmp;
    }

    c = x * y;
    d = x % y;
    while (d != 0)
    {
        x = y;
        y = d;

        d = x % y;
    }

    printf("%d\n",c/y);
}

int main(void)
 
{
    int x,y;
    printf("x = "); scanf("%d",&x);
    printf("y = "); scanf("%d",&y);
    lcm(x,y);
    return 0;
}

/*実行結果
x = 32
y = 2
32
*/