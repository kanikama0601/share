/*18番 小原 櫂
 * 「第8回レポート プログラム1」*/

#include <stdio.h>

int leap(int year)
{
	int judge = 0;
	if (year%4 == 0)
	{
		judge = 1;

		if (year%100 == 0)
		{
			judge = 0;
			if (year%400 == 0)
			{
				judge = 1;
			}
		}
		
	}

	if (judge == 1)
	{
		printf("閏年\n");
	}
	else
	{
		printf("閏年ではない\n");
	}
}

int main(void)


{
    int x;
    printf("x = "); scanf("%d",&x);
    leap(x);
    return 0;
}

/*実行結果
x = 2000
閏年
*/