/*18番 小原 櫂
 * 「第8回レポート プログラム2」*/

#include <stdio.h>

int prime(int x)
{
    int sum = 0;
    for(int i = 1;i<=x;i++)
    {
        if(x%i==0)
        {
            sum++;
        }
    }

    if(sum <= 2)
    {
        printf("素数である\n");
    }
    else
    {
        printf("素数でない\n");
    }
}
int main(void)
 
{
    int n;
    printf("n = "); scanf("%d",&n);
    prime(n);

    return 0;
}

/*実行結果
n = 3
素数である
*/