#include <stdio.h>

int main(void)
{
	printf("    _ ∧ ∧\n");
	printf("～' _(´ー')  にゃ～\n");
	printf("  UU  U  U\n");
}
