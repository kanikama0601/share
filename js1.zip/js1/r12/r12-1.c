/*18番 小原 櫂
 * 「第12回レポート プログラム1」*/

#include <stdio.h>
#include <string.h>
void mystrcpy(char *s1,char *s2)
{
    strcpy(s1,s2);
}

int main(void)
 
{
    char s1[1000];
    char s2[1000];
    printf("s1 = "); scanf("%s",s1);
    scanf("%s",s2);
    mystrcpy(s2,s1);
    printf("s2 = %s\n",s2);
    return 0;
}

/*実行結果
s1 = nekochan
s2 = nekochan
*/