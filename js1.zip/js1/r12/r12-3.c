/*18番 小原 櫂
 * 「第12回レポート プログラム3」*/

#include <stdio.h>
#include <string.h>
int mystrcmp(char *s1, char *s2)
{
    int s1len,s2len,i;
    s1len = strlen(s1);
    s2len = strlen(s2);
    i = 0;

    int s1count = 0;
    int s2count = 0;
    while(i <= s1len)
    {
        s1count += s1[i];
        i++;
    }
    i = 0;
    while(i <= s2len)
    {
        s2count += s2[i];
        i++;
    }
    return (s1count-s2count);
    //return (strcmp(s1,s2))　でOK
}
int main(void)
 
{
    char s1[1000];
    char s2[1000];
    int n;
    printf("s1 = "); scanf("%s",s1);
    printf("s2 = "); scanf("%s",s2);
    n = mystrcmp(s1,s2);
    if (n>0)    printf("s1(%s) > s2(%s)\n",s1,s2);
    else if(n==0) printf("s1(%s) = s2(%s)\n",s1,s2);
    else printf("s1(%s) < s2(%s)\n",s1,s2);
    return 0;
}

/*実行結果
s1 = nekochan
s2 = nekocham
s1(nekochan) > s2(nekocham)
*/