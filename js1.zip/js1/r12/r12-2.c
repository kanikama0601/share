/*18番 小原 櫂
 * 「第12回レポート プログラム2」*/

#include <stdio.h>
#include <string.h>
void mystrcat(char *s1, char *s2)
{
    s1 = strcat(s1,s2);
}

int main(void)
 
{
    char s1[1000];
    char s2[1000];
    printf("s1 = "); scanf("%s",s1);
    printf("s2 = "); scanf("%s",s2);
    mystrcat(s1,s2);
    printf("s1 + s2 = %s\n",s1);
    return 0;
}

/*実行結果
s1 = nekochan
s2 = kawaii
s1 + s2 = nekochankawaii
*/