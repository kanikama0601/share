/*18番 小原 櫂
 * 「第9回レポート プログラム2」*/

#include <stdio.h>
int readdata(int a[])
{
    int n,i;

    printf("n = "); scanf("%d",&n);
    for(i=0;i<n;i++)
    {
        printf("a[%d] = ",i); scanf("%d",&a[i]);
    }

    return n;
}

void sort(int a[], int n)
{
    int index,i,j,temp;
    for(i=0; i<n-1; i++)
    {
        index = i;
        for(j = i + 1; j<n; j++)
        {
            if(a[j] > a[index])
            {
                index = j;
            }
        
        }
        temp = a[i];
        a[i] = a[index];
        a[index] = temp;

    }
}

void writedata(int a[],int n)
{
    for(int i = 0;i < n;i++)
    {
        printf("a[%d] : %d\n",i,a[i]);
    }
}

int main(void)
 
{
    int a[10],n;
    n = readdata(a);
    sort(a,n);
    printf("\n");
    writedata(a,n);
    
    return 0;
}

/*実行結果
a[0] = 1
a[1] = 3
a[2] = 4
a[3] = 6
a[4] = 7

a[0] : 7
a[1] : 6
a[2] : 4
a[3] : 3
a[4] : 1
*/