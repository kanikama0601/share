/*18番 小原 櫂
 * 「第9回レポート プログラム3」*/

#include <stdio.h>
int readdata(int a[])
{
    int n,i;

    printf("n = "); scanf("%d",&n);
    for(i=0;i<n;i++)
    {
        printf("a[%d] = ",i); scanf("%d",&a[i]);
    }

    return n;
}

void histogram(int a[],int n)
{
    for(int i = 0;i < n;i++)
    {
        printf("a[%d] = %d : ",i,a[i]);
        for(int j = 0;j < a[i];j++)
        {
            printf("*");
        }
        printf("\n");
    }
}

int main(void)
 
{
    int a[100],n;
    n = readdata(a);
    printf("\n");
    histogram(a,n);

    return 0;
}

/*実行結果
a[0] = 1
a[1] = 3
a[2] = 4
a[3] = 6
a[4] = 7

a[0] = 1 : *
a[1] = 3 : ***
a[2] = 4 : ****
a[3] = 6 : ******
a[4] = 7 : *******
*/