/*18番 小原 櫂
 * 「第9回レポート プログラム2」*/

#include <stdio.h>

int readdata(int a[])
{
    int n,i;

    printf("n = "); scanf("%d",&n);
    for(i=0;i<n;i++)
    {
        printf("a[%d] = ",i); scanf("%d",&a[i]);
    }

    return n;
}

int maxf(int a[] ,int n)
{
    int i;
    int max = a[0];
    for(i=0;i<n;i++)
    {
        if(max<a[i])
        {
            max = a[i];
        }
    }

    return max;
}

int main(void)
 
{
    int a[10],n,max;
    n = readdata(a);
    printf("最大値 = %d\n",maxf(a,n));
    return 0;
}

/*実行結果
n = 5
a[0] = 1
a[1] = 2
a[2] = 3
a[3] = 4
a[4] = 5
最大値 = 5
*/