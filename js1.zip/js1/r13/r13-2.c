/*18番 小原 櫂
 * 「第13回レポート プログラム2」*/

#include <stdio.h>
#include <string.h>
int main(void)
 
{
    int i;
    int length_list[21];
    for(i = 0;i <= 20;i++)
    {
        length_list[i] = 0;
    }

    char temp[300];
    int templong;
    char fname[1000];
    printf("入力ファイル名 = "); scanf("%s",fname);
    FILE *fp;
    if((fp = fopen(fname,"r")) == NULL)
    {
        printf("ファイルを開けませんでした\n");
        return 1;
    }

    while((fscanf(fp,"%s",temp))!= EOF)
    {
        templong=strlen(temp);
        length_list[templong]++;
    }
    for(i = 1;i <= 20;i++)
    {
        printf("%d:\t%d\n",i,length_list[i]);
    }

    fclose(fp);
    return 0;
}

/*実行結果
入力ファイル名 = snow_white.txt
1:      60
2:      427
3:      931
4:      561
5:      427
6:      268
7:      172
8:      74
9:      40
10:     42
11:     19
12:     7
13:     9
14:     11
15:     0
16:     1
17:     0
18:     0
19:     0
20:     0
*/