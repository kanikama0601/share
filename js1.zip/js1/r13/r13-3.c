/*18番 小原 櫂
 * 「第13回レポート プログラム3」*/
#include <stdio.h>
#include <string.h>
int main(void)
 
{
    int i;
    int length_list[21];
    for(i = 0;i <= 20;i++)
    {
        length_list[i] = 0;
    }

    char temp[1000];
    int templong;
    char fname[1000];
    printf("入力ファイル名 = "); scanf("%s",fname);
    FILE *fp;
    if((fp = fopen(fname,"r")) == NULL)
    {
        printf("ファイルを開けませんでした\n");
        return 1;
    }
    // FILE *fp;
    // fp = fopen("snow_white.txt","r");

    int sum = 0;
    while((fscanf(fp,"%s",temp))!= EOF)
    {
        templong=strlen(temp);
        length_list[templong]++;
        sum ++;
    }
    for(i = 1;i <= 20;i++)
    {
        printf("%d:\t%.2lf %%\n",i,(double)length_list[i]/sum*100);
    }

    fclose(fp);
    return 0;
}

/*実行結果
入力ファイル名 = snow_white.txt
1:      1.97 %
2:      14.00 %
3:      30.53 %
4:      18.40 %
5:      14.00 %
6:      8.79 %
7:      5.64 %
8:      2.43 %
9:      1.31 %
10:     1.38 %
11:     0.62 %
12:     0.23 %
13:     0.30 %
14:     0.36 %
15:     0.00 %
16:     0.03 %
17:     0.00 %
18:     0.00 %
19:     0.00 %
20:     0.00 %
*/