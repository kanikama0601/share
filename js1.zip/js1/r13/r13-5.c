/*18番 小原 櫂
 * 「第13回レポート プログラム5」*/

#include <stdio.h>
#include <string.h>
int main(void)
 
{
    int i;
    int length_list[21];
    for(i = 0;i <= 20;i++)
    {
        length_list[i] = 0;
    }

    char temp[300];
    int templong;
    char fname[1000];
    printf("入力ファイル名 = "); scanf("%s",fname);
    FILE *fp;
    if((fp = fopen(fname,"r")) == NULL)
    {
        printf("ファイルを開けませんでした\n");
        return 1;
    }

    while((fscanf(fp,"%s",temp))!= EOF)
    {
        templong=strlen(temp);
        length_list[templong]++; //n文字の単語カウント
    }
    for(i = 1;i <= 20;i++)
    {
        printf("%d:",i);
        while((length_list[i]/10) != 0)
        {
            length_list[i] = length_list[i] - 10;
            printf("*");
        }
        while((length_list[i]/5) != 0)
        {
            length_list[i] = length_list[i] -5;
            printf("+");
        }
        while((length_list[i]) != 0)
        {
            length_list[i] --;
            printf(".");
        }
        printf("\n");
    }

    fclose(fp);
    return 0;
}

/*実行結果
1:******
2:******************************************+..
3:*********************************************************************************************.
4:********************************************************.
5:******************************************+..
6:**************************+...
7:*****************..
8:*******....
9:****
10:****..
11:*+....
12:+..
13:+....
14:*.
15:
16:.
17:
18:
19:
20:
*/