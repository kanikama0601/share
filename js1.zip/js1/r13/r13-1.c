/*18番 小原 櫂
 * 「第13回レポート プログラム1」*/

#include <stdio.h>
int main(void)
 
{
    char fname[1000];
    printf("ファイル名 = "); scanf("%s",fname);
    FILE *fp;
    if((fp = fopen(fname,"r")) == NULL)
    {
        printf("ファイルを開けませんでした\n");
        return 1;
    }

    int temp,temp2;
    int kamoku = 0,tani = 0,goukei = 0,sum = 0;
    while((fscanf(fp,"%d %d",&temp,&temp2))!=EOF)
    {
        kamoku++;
        goukei += (temp * temp2);
        tani += temp2;
    }
    printf("成績ファイル名 = %s\n",fname);
    printf("科目数 = %d\n",kamoku);
    printf("総単位数 = %d\n",tani);
    printf("合計 = %d\n",goukei);
    printf("平均 = %2.6lf\n",(double)goukei/tani);

    fclose(fp);
    return 0;
}

/*実行結果
ファイル名 = seiseki2.txt
成績ファイル名 = seiseki2.txt
科目数 = 10
総単位数 = 21
合計 = 1723
平均 = 82.047619
*/