/*18番 小原 櫂
 * 「第三回レポート プログラム1」*/

#include <stdio.h>
int main(int argc, char *argv[])
{
    if(argv[1] == NULL || argv[2] == NULL || argv[3] != NULL)
    {
        printf("使用方法: ./r14-2 file1 file2\n");
        return 1;
    }

    FILE *fp1;
    if((fp1 = fopen(argv[1],"r")) == NULL)//開けないとNULLになる
    {
        printf("ファイル名: %sを開けませんでした\n",argv[1]);
    }
    FILE *fp2 = fopen(argv[2],"w");

    char buffer[1000];
    while(fgets(buffer,1000,fp1) != NULL)
    {
        fputs(buffer,fp2);
    }
    printf("successful!!");
    fclose(fp1);
    fclose(fp2);

    return 0;
}

/*実行結果
bash:$ ./r14-2 file1.txt file2.txt
*/