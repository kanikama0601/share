/*18番 小原 櫂
 * 「第三回レポート プログラム1」*/

#include <stdio.h>
#include <string.h>
#include <math.h>
int calc(int a[],int len)
{
    int temp = 0;
    int x;
    for(int i = 0;i < len;i++)
    {

        temp += a[i] * (int)(pow(10,len-i-1));
    }
    return temp;
}

int main(int argc, char *argv[])
 
{
    char temp[1000];
    char temp2[1000];
    int len = strlen(argv[1]),len2 = strlen(argv[2]);
    int num[len],num2[len2];
    
    strcpy(temp,argv[1]);
    strcpy(temp2,argv[2]);
    for(int i = 0;i < 3;i++)
    {
        num[i] = temp[i] - 48;
    }
    for(int i = 0;i < len;i++)
    {
        num2[i] = temp2[i] -48;
    }
    printf("%d\n",num[1]);
    int a,b;
    a = calc(num,len);
    b = calc(num2,len2);
    printf("%d + %d = %d",a,b,a+b);

    return 0;
}

/*実行結果

*/