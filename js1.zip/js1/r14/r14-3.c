/*18番 小原 櫂
 * 「第三回レポート プログラム1」*/

#include <stdio.h>
#include <string.h>
int main(int argc, char *argv[])
 
{
    char temp[1000];
    char temp2[1000];
    strcpy(temp,argv[1]);
    strcpy(temp2,argv[2]);//ポインタ内をcharにコピーしてからintに変換
    printf("%dちんちん\n",temp[0]+temp2[0]-96);
    return 0;
}

/*実行結果
bash:$ ./r14-3 5 6
11ちんちん
*/