/*18番 小原 櫂
 * 「第三回レポート プログラム1」*/

#include <stdio.h>
int main(int argc, char *argv[])
 
{
    if(argv[1] == NULL) //文字無いエラー
    {
        printf("使用方法：./r14-1 file\n");
        return 1;
    }
    
    FILE *fp;
    if((fp = fopen(argv[1],"r")) == NULL)//開けないエラー
    {
        printf("ファイル名:%s を開けませんでした\n",argv[1]);
        fclose(fp);
        return 1;
    }

    char buffer[1000];
    while((fgets(buffer,1000,fp)) != NULL)
    {
        printf("%s",buffer);
    }
    fclose(fp);

    printf("\n");
    return 0;
}

/*実行結果
bash:$ ~/js1/r14$ ./r14-1 file1.txt
大塚製薬って名前の癖に
MatchとかオロナミンCとか体に悪そうなものばっかり売ってるの
なあぜなあぜ？
*/