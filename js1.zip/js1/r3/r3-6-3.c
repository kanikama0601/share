/*18番 小原 櫂
 * 「第三回レポート プログラム6-3」*/

#include <stdio.h>
int main(void)
{
    int m = 0;
    for(int i = 1; m <= 100; i++)
    {
        m = i * i;
        if(m <= 100)
        {
            printf("%d ",m);
        }
    }

    printf("\n");
    return 0;
}

/*実行結果
1 4 9 16 25 36 49 64 81 100
*/