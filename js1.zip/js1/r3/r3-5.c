/*18番 小原 櫂
 * 「第三回レポート プログラム5」*/

#include <stdio.h>
int main(void)
 
{
    int x,y,c;
    printf("x = "); scanf("%d",&x);
    printf("y = "); scanf("%d",&y);

    if(x < y)
    {
        int temp = x;
        x = y;
        y = temp;
    }

    c = x % y;
    while(c != 0)
    {
        x = y;
        y = c;
        c = x % y;
    }

    printf("gcm = %d\n",y);
}

/*実行結果
x = 60
y = 45
gcm = 15
*/