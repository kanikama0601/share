/*18番 小原 櫂
 * 「第三回レポート プログラム6-4」*/

#include <stdio.h>
int main(void)
{
    int m = 0;
    for(int i = 1; m <= 199; i++)
    {
        m = (i*i) + (i*i - 1) ;
        if(m <= 199)
        {
            printf("%d ",m);
        }
    }

    printf("\n");
    return 0;
}

/*実行結果
1 7 17 31 49 71 97 127 161 199
*/