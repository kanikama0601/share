/*18番 小原 櫂
 * 「第三回レポート プログラム6-1」*/

#include <stdio.h>
int main(void)
 
{
    for(int i = 1;i <= 20;i = i + 2)
    {
        printf("%d ",i);
    }

    printf("\n");
}

/*実行結果
1 3 5 7 9 11 13 15 17 19 
*/