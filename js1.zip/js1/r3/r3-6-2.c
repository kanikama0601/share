/*18番 小原 櫂
 * 「第三回レポート プログラム6-2」*/

#include <stdio.h>
int main(void)
{
    int m = 0;
    for(int i = 0; m <= 90; i += 2)
    {
        m = m + i;
        if(m <= 90)
        {
            printf("%d ",m);
        }
    }

    printf("\n");
    return 0;
}

/*実行結果
0 2 6 12 20 30 42 56 72 90 
*/