#include <stdio.h>
int main(void)
{
	int year;
	printf("y = ");scanf("%d",&year);
	int judge = 0;
	if (year%4 == 0)
	{
		judge = 1;

		if (year%100 == 0)
		{
			judge = 0;
			if (year%400 == 0)
			{
				judge = 1;
			}
		}
		
	}

	if (judge == 1)
	{
		printf("閏年\n");
	}
	else
	{
		printf("閏年ではない\n");
	}

	
}
