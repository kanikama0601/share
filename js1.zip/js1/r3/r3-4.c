/*18番 小原 櫂
 * 「第三回レポート プログラム4」*/

#include <stdio.h>
int main(void)
 
{
    int result,n;
    int i;
    result = 1;
    printf("n = "); scanf("%d",&n);
    if(n==1||n==2)
    {
        result = 1;
    }
    else
    {
        for (i=2;i<n;i++)
        {
            if(n % i == 0)
            {
                result = 0;
                break;
            }
        }
    }

    if(result == 1)
    {
        printf("素数\n");
    }
    else if(result == 0)
    {
        printf("素数ではない\n");
    }
}

/*実行結果
n = 13
素数
*/