/*18番 小原 櫂
 * 「第三回レポート プログラム1」*/

#include <stdio.h>

int main(void)
{
	int point;
	printf("点数 = "); scanf("%d",&point);

	if (point > 100 || point < 0)
	{
		printf("不正な値です\n");
	}

	else if (point >= 80)
	{
		printf("優\n");
	}
	else if (point >= 70)
	{
		printf("良\n");
	}
	else if (point >= 60)
	{
		printf("可\n");
	}
	else
	{
		printf("不可\n");
	}
}

/*実行結果1
 * a = 73
 * 良
 *
 * 実行結果2
 * a = 91
 * 優
 * */
