/*18番 小原 櫂
 * 「第三回レポート プログラム1」*/

#include <stdio.h>
int main(void)
 
{
    printf("(1)");
    for(int i = 1;i <= 20;i = i + 2)
    {
        printf("%d ",i);
    }

    printf("\n(2)");
    int m = 0;
    for(int i = 0; m <= 90; i += 2)
    {
        m = m + i;
        if(m <= 90)
        {
            printf("%d ",m);
        }
    }

    printf("\n(3)");
    m = 0;
    for(int i = 1; m <= 100; i++)
    {
        m = i * i;
        if(m <= 100)
        {
            printf("%d ",m);
        }
    }

    printf("\n(4)");
    m = 0;
    for(int i = 1; m <= 199; i++)
    {
        m = (i*i) + (i*i - 1) ;
        if(m <= 199)
        {
            printf("%d ",m);
        }
    }

    printf("\n");
    return 0;
}

/*実行結果
(1)1 3 5 7 9 11 13 15 17 19 
(2)0 2 6 12 20 30 42 56 72 90 
(3)1 4 9 16 25 36 49 64 81 100 
(4)1 7 17 31 49 71 97 127 161 199
*/