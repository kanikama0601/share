/*18番 小原 櫂
 * 「第三回レポート プログラム2」*/

#include <stdio.h>
#include <math.h>

int main(void)
{
	int a,b;
	double c,x;

	printf("a = "); scanf("%d",&a);
	printf("b = "); scanf("%d",&b);
	printf("c = "); scanf("%lf",&c);

	x = (b * b) - (4 * a * c);

	if (x > 0)
	{
		printf("x = %0.2lf,%0.2lf\n",(-b+sqrt((b*b)-(4*a*c)))/(2*a),(-b-sqrt((b*b)-(4*a*c)))/(2*a));
	}
	else if (x == 0)
	{
		printf("x = %0.2lf\n",(-b+sqrt((b*b)-(4*a*c)))/(2*a));
	}
	else
	{
		printf("実数解無し\n");
	}
}

/*実行結果1
 * a = 1
 * b = 2
 * c = 1
 * x = -1.00
 *
 *実行結果2
 * a = 1
 * b = 1
 * c = 1
 * 実数解無し
 * */
