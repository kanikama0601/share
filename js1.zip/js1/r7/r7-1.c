/*18番 小原 櫂
 * 「第7回レポート プログラム1」*/

#include <stdio.h>
int main(void)
 
{
    int a[3] [5];
    /*入力*/
    for(int i = 0;i < 5;i++)
    {
        scanf("%d %d",&a[0][i],&a[1][i]);
    }

    for(int i = 0;i < 5;i++)
    {
        for(int e = 0;e<=1;e++)
        {
                printf("%d ",a[e][i]);
        }
        printf(" %.1f\n",(double)(a[0][i]+a[1][i])/2);
    }


    return 0;
}

/*実行結果
70 65
92 83
75 85
66 74
89 92
70 65 67.5
92 83 87.5
75 85 80.0
66 74 70.0
89 92 90.5
*/