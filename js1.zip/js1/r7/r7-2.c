/*18番 小原 櫂
 * 「第7回レポート プログラム2」*/

#include <stdio.h>
int main(void)
 
{
    int a[2][6],sum1,sum2;
    sum1 = 0;
    sum2 = 0;
    /*入力*/
    for(int i = 0;i < 5;i++)
    {
        scanf("%d %d",&a[0][i],&a[1][i]);
    }
    
    for(int i = 0;i < 5;i++)
    {
        printf("%d %d\n",a[0][i],a[1][i]);
        sum1 += a[0][i];
        sum2 += a[1][i];
    }

    printf("%.1f %.1f\n",(double)sum1/5,(double)sum2/5);
}

/*実行結果
70 65
92 83
75 85
66 74
89 92
70 65
92 83
75 85
66 74
89 92
78.4 79.8
*/