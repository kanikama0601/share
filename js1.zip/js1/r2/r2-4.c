/*18番 小原 櫂
 * 「第二回レポート プログラム2」*/

#include <stdio.h>
#include <math.h>

int main(void)
{
	double a,x,y,rad;

	printf ("a = "); scanf("%lf" , &a);
	
	rad = 75 * 3.14159265358979323846264338 / 180;
	y = sin(rad);

	x = 1 / y * a;

	printf ("x = %0.3lf\n" , x);
	
	return 0;
}

/*実行結果
 *
 * u=5
 * l=8
 * h=3
 * s=19.50 */

