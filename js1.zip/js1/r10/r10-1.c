/*18番 小原 櫂
 * 「第10回レポート プログラム1」*/

#include <stdio.h>
#include <string.h>
int main(void)
 
{
    char filename[100];
    printf("ファイル名を入力\n");
    scanf("%s",filename);

    int sum = 0;
    FILE *fp = fopen(filename,"r");

    char buffer[1000];
    while((fgets(buffer,1000,fp)) != NULL)
    {
        int wordcount = strlen(buffer);
        sum += wordcount;
    }
    fclose(fp);

    printf("文字数 = %d\n",sum);
    return 0;
}

/*実行結果
ファイル名を入力
snow_white.txt
文字数 = 16009
*/