/*18番 小原 櫂
 * 「第10回レポート プログラム2」*/

#include <stdio.h>
#include <string.h>
int main(void)
 
{
    char filename[100];
    printf("ファイル名を入力\n");
    scanf("%s",filename);

    int count = 0;
    FILE *fp = fopen(filename,"r");
    char buffer;

    while((buffer = (fgetc(fp))) != EOF)
    {
        if(buffer == '\n')
        {
            count++;
        }
    }
    fclose(fp);

    printf("行数 = %d\n",count);
    return 0;
}

/*実行結果
ファイル名を入力
snow_white.txt
行数 = 80
*/