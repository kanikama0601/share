/*18番 小原 櫂
 * 「第10回レポート プログラム3」*/

#include <stdio.h>
#include <string.h>
int main(void)
 
{
    char filename[100];
    printf("ファイル名を入力\n");
    scanf("%s",filename);

    int big = 0;
    int small = 0;
    int num = 0;

    FILE *fp = fopen(filename,"r");
    char buffer;

    while((buffer = (fgetc(fp))) != EOF)
    {
        if(buffer >= 'a' && buffer <= 'z')
        {
            small++;
        }
        else if(buffer >= 'A' && buffer <= 'Z')
        {
            big++;
        }
        else if(buffer >= '1' && buffer <= '9')
        {
            num++;
        }
    }
    fclose(fp);

    printf("大文字 = %d\n小文字 = %d\n数字 = %d\n",big,small,num);
    return 0;
}

/*実行結果
ファイル名を入力
snow_white.txt
大文字 = 233
小文字 = 11949
数字 = 0
*/