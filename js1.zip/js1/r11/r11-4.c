/*18番 小原 櫂
 * 「第11回レポート プログラム4」*/

#include <stdio.h>
int main(void)
 
{
    int i;
    char word[1000];
    char word2[1000];
    printf("文字列 = ");
    scanf("%s",word);
    for(i=0;word[i] != '\0';i++)
        word2[i] = word[i];

    printf("word = %s\n",word);
    printf("word2 = %s\n",word2);
    return 0;
}

/*実行結果
文字列 = nekochan
word = nekochan
word2 = nekochan
*/