/*18番 小原 櫂
 * 「第11回レポート プログラム1」*/

#include <stdio.h>
#include <stdlib.h>
int main(void)

{
    FILE *fp;
    char buffer[1000];

    fp = popen("wc -w < snow_white.txt", "r");
    if (fp == NULL) {
        printf("Failed to run command\n" );
        exit(1);
    }

    printf("単語数 = ");
    while (fgets(buffer, sizeof(buffer), fp) != NULL) {
        printf("%s", buffer);
    }

    pclose(fp);

    return 0;
}

/*実行結果
単語数 = 3049
*/