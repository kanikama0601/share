/*18番 小原 櫂
 * 「第11回レポート プログラム3」*/

#include <stdio.h>
int main(void)
 
{
    int i;
    char word[1000];
    printf("文字列 = ");
    scanf("%s",word);

    for(i=0;word[i] != '\0';i++);
    printf("文字列の長さ = %d\n",i);
    return 0;
}

/*実行結果
文字列 = shortcake
文字列の長さ = 9
*/