/*18番 小原 櫂
 * 「第11回レポート プログラム2」*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
 
{
    FILE *fp;
    char buffer[1000];
    char index[1000];
    char *temp;
    int cullent_length;
    int max_length = 0;
    fp = fopen("snow_white.txt","r");
    while((fgets(buffer,1000,fp)) != NULL)
    {
        temp = strtok(buffer," ,\"");
        while(temp != NULL)
        {
            cullent_length = strlen(temp);
            if(max_length < cullent_length)
            {
                strcpy(index,temp);
                max_length = cullent_length;
            }
            temp = strtok(NULL," ,\"");//スペースと,と"で区切る + 先程の文字の次の文字から開始
        }
    }
    fclose(fp);
    printf("最も長い単語 = %s\nその文字数 = %d\n",index,max_length);
    return 0;
}

/*実行結果
最も長い単語 = embroidery-frame
その文字数 = 16
*/