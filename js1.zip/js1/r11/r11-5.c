/*18番 小原 櫂
 * 「第三回レポート プログラム1」*/

#include <stdio.h>
int main(void)
 
{
    int i,j;
    char word[1000];
    char word2[1000];
    printf("word = ");
    scanf("%s",word);
    printf("word2 = ");
    scanf("%s",word2);

    for(i=0;word[i] != '\0';i++);
    for(j=0;word2[j] != '\0';j++)
    {
        word[j+i] = word2[j];
    }

    printf("結合した単語 = %s\n",word);
    return 0;
}

/*実行結果
word = nekochan
word2 = kawaii
結合した単語 = nekochankawaii
*/