/*18番 小原 櫂
 * 「第五回レポート プログラム2」*/

#include <stdio.h>
#include <math.h>
int main(void)

{
    int num[10];
    int sum = 0;
    double sigma = 0;
    double ave = 0;

    for(int i = 0; i <= 9; i++)
    {
        scanf("%d",&num[i]);
    }

    for(int i = 0;i<=9;i++)
    {
        sum = sum + num[i];
    }
    ave = (double)sum / 10;

    for(int i = 0;i <= 9;i++)
    {
        sigma = sigma + (num[i] - ave) * (num[i] - ave);
    }

    sigma = sqrt(sigma / 10);

    printf("標準偏差 = %lf\n",sigma);

    return 0;
}

/*実行結果
1 2 3 4 5 6 7 8 9 10
標準偏差 = 2.872281
*/