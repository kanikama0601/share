/*18番 小原 櫂
 * 「第五回レポート プログラム1」*/

#include <stdio.h>
int main(void)

{
    int num[10];
    int sum = 0;
    int ave;

    for(int i = 0; i <= 9; i++)
    {
        scanf("%d",&num[i]);
    }

    for(int i = 0;i <= 9; i++)
    {
        sum = sum + num[i];
    }
    printf("合計 = %d  平均 = %0.2lf\n",sum,(double)sum/10);

    return 0;
}

/*実行結果
1 2 3 4 5 6 7 8 9 10
合計 = 55  平均 = 5.50
*/