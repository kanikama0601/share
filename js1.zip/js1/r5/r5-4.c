/*18番 小原 櫂
 * 「第五回レポート プログラム3」*/

#include <stdio.h>
int main(void)

{
    int num[10];
    int a = 0;

    for(int i = 0; i <= 9; i++)
    {
        scanf("%d",&num[i]);
    }
    int max = num[0];
    int min = num[0];

    for(int i = 0;i<=9;i++)
    {
        if(max <= num[i])
        {
            max = num[i];
            a = i;
        }

    }

    for(int i = 0;i<=9;i++)
    {
        if(min <= num[i])
        {
            if (num[i] == num[a])
            {}
            else
            {
                min = num[i];
            }
        }

    }

    printf("1番目 = %d  2番目 = %d\n",max,min);

    return 0;
}

/*実行結果
1 2 5 10 3 8 7 4 9 6
最大値 = 10  最小値 = 1
*/